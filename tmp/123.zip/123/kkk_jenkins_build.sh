#!/bin/bash

function usage()
{
cat << EOF
 USAGE: [-o] [-u] [-v VERSION_NAME] [-t BUILD_VARIANT]
 No ARGS means use default build option
 WHERE: -d = device type name
        -i = jenkins build id
        -o = generate ota package
        -u = generate update.img
        -v = set build version name for output image folder
        -t = set build android type(userdebug、user)
        -j = set jenkins workspace
        -w = enable wipe user data
        -r = set enable adb root in user mode
EOF
 exit 1
}

function secure_signer()
{
	echo "sign user image"
	in=$1
	out=$2
	time=`date +%Y%m%d%H%M%S`
	PRIVATE_KEY=build/target/product/security/privateKey.bin
	PUBLIC_KEY=build/target/product/security/publicKey.bin
	
	if [ -z "$in" ]; then 
		echo "Please set the input file to secure sign!" 
		exit 1
	fi
	
	if [ -z "$out" ]; then 
		out=$in; 
	fi

	echo "sign user image $in to $out at $time"
	cd $PROJECT_TOP
	
	#Sign images
	cmd="./SecureBootConsole -p -si ${PRIVATE_KEY} ${in}"

	if [ "${in##*/}"x = "kp0001_loader.bin"x ]; then
		cmd="./SecureBootConsole -p -slx ${PRIVATE_KEY} ${PUBLIC_KEY} ${in}"
	fi
	
	if [ "${in##*/}"x = "update.img"x ]; then
		cmd="./SecureBootConsole -p -sh ${PRIVATE_KEY}  ${in}"
	fi

	$cmd
	
	result=$?
	if [ $result -ne 0 ]; then
		echo 'resign failed, skip'
		cd -
		exit 1
	else
		if [ -z $2 ]; then
			echo "sign user image $in"
		else
			mv ${in} ${out}
		fi
	fi
	cd -
}

function gen_user_image()
{
	echo "generate user update image..."
	cd ${IMAGE_PATH}/../update_gen/rockdev
	chmod +x ./mkupdate.sh
	chmod +x ./afptool
	chmod +x ./rkImageMaker
	chmod +x ./unpack.sh
	./mkupdate.sh
	if [ $? -eq 0 ]; then
	  echo "Make user update image ok!"
	else
	  echo "Make factory update image failed!"
	  exit 1
	fi
	cd -

	#Xandy add for update.img secure boot sign
	secure_signer ${IMAGE_PATH}/../update_gen/rockdev/update.img ${IMAGE_PATH}/update_sign_$ZIP_FILE.img
}

function gen_factory_image()
{
	echo "gen factory upfdate image..."
	cp -rf ${IMAGE_PATH}/../update_gen/rockdev/factory_package-file ${IMAGE_PATH}/../update_gen/rockdev/package-file
	mkdir -p ${IMAGE_PATH}/../FACTORY_IMAGE
	cd ${IMAGE_PATH}/../update_gen/rockdev
	chmod +x ./mkupdate.sh
	chmod +x ./afptool
	chmod +x ./rkImageMaker
	chmod +x ./unpack.sh
	./mkupdate.sh
	if [ $? -eq 0 ]; then
	  echo "Make factory update image ok!"
	else
	  echo "Make factory update image failed!"
	  exit 1
	fi
	cd -

	#Xandy add for update.img secure boot sign
	secure_signer ${IMAGE_PATH}/../update_gen/rockdev/update.img ${IMAGE_PATH}/../FACTORY_IMAGE/factory_update_sign_$ZIP_FILE.img	
}

BUILD_UPDATE_IMG=false
BUILD_OTA=false
BUILD_VERSION="V00.00.00.01"
BUILD_VARIANT=userdebug
DEVICE_NAME=kp0001_excavator
JENKINS_BUILD_ID="1"
#jenkins workspace
JENKINS_WORKSPACE=/home/jenkins/workspace
export CONFIG_ENABLE_USER_ADB_ROOT=false
export WIPE_USER_DATA_CONFIG=false

if [ $# -eq 0 ];then
	usage
fi

# check pass argument
while getopts "d:i:j:ort:uv:w" arg
do
  case $arg in
    d)
      DEVICE_NAME=$OPTARG
      ;;
    i)
      JENKINS_BUILD_ID=$OPTARG
      ;;
    o)
      echo "will build ota package"
      BUILD_OTA=true
      ;;
    u)
      echo "will build update.img"
      BUILD_UPDATE_IMG=true
      ;;
    v)
      BUILD_VERSION=$OPTARG
      ;;
    t)
      BUILD_VARIANT=$OPTARG
      ;;
    j)
      JENKINS_WORKSPACE=$OPTARG
      ;;
    r)
      echo "Enable adb root in user mode"
      export CONFIG_ENABLE_USER_ADB_ROOT=true
      ;;
    w)
      echo "Enable wipe user data"
      export WIPE_USER_DATA_CONFIG=true
     ;;
    ?)
      usage 
     ;;
  esac
done

source build/envsetup.sh >/dev/null && setpaths

lunch $DEVICE_NAME-$BUILD_VARIANT
TARGET_PRODUCT=`get_build_var TARGET_PRODUCT`

if [ "$TARGET_PRODUCT" != "$DEVICE_NAME" ];then
	echo -e "\e[0;31;1mHave you lunch the combo?\e[0m"
	exit 1
fi

#set jdk version
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib:$JAVA_HOME/lib/tools.jar
# source environment and chose target product
DEVICE=`get_build_var TARGET_PRODUCT`
#BUILD_VARIANT=`get_build_var TARGET_BUILD_VARIANT`
UBOOT_DEFCONFIG=${DEVICE_NAME}_defconfig
KERNEL_DEFCONFIG=${DEVICE_NAME}_defconfig
KERNEL_DTS=${DEVICE_NAME}
PACK_TOOL_DIR=RKTools/linux/Linux_Pack_Firmware
MANIFEST_REPO_DIR=.repo/manifests
IMAGE_PATH=rockdev/Image-$TARGET_PRODUCT
U_BOOT_DIR=u-boot
export PROJECT_TOP=`gettop`
#export build version to build environment
export ANDROID_BUILD_ID=$BUILD_VERSION
USER_NAME=`whoami`

#lunch $DEVICE-$BUILD_VARIANT

PLATFORM_VERSION=`get_build_var PLATFORM_VERSION`
DATE=$(date  +%Y%m%d_${JENKINS_BUILD_ID})
STUB_PATH=Image/"$KERNEL_DTS"_"$PLATFORM_VERSION"_"$DATE"_"$BUILD_VERSION"
STUB_PATH="$(echo $STUB_PATH | tr '[:lower:]' '[:upper:]')"
ZIP_SRC_PATH=$STUB_PATH
ZIP_FILE=`echo ${ZIP_SRC_PATH#*/}`
#echo ***$ZIP_FILE***
#export STUB_PATH=$PROJECT_TOP/$STUB_PATH
STUB_PATCH_PATH=$STUB_PATH/PATCHES
#echo $STUB_PATH

#BUILD_THREAD
BUILD_THREAD=`sed -n "N;/processor/p" /proc/cpuinfo|wc -l`
let "ANDROID_THREAD=$BUILD_THREAD"

# sync code
if [ "$USER_NAME" = "jenkins" ] ; then
	echo    "******************************"
	echo    "*         repo sync          *"
	echo    "******************************"
	#cd $MANIFEST_REPO_DIR
	#git checkout -B master
	#git pull origin master

	#cd -

	#.repo/repo/repo start --all master
	#.repo/repo/repo forall -c "git fetch"
	cd vendor/rockchip/common
	git checkout ./
	cd -
	.repo/repo/repo sync
	if [ $? -eq 0 ]; then
		echo "repo sync success!"
	else
		echo -e "\e[0;31;1mrepo sync error!\e[0m"
		exit 1
	fi
fi

# In user buid mode build the ota package
if [ "$BUILD_VARIANT" = "user" ] ; then
	echo    "******************************"
	echo    "*      user build mode       *"
	echo    "******************************"
	BUILD_OTA=true
fi

# build uboot
echo    "******************************"
echo    "*     Make AArch64 Uboot     *"
echo    "******************************"
cd u-boot && make distclean --jobs=$BUILD_THREAD && make $UBOOT_DEFCONFIG && make ARCHV=aarch64 --jobs=$BUILD_THREAD && cd -
if [ $? -eq 0 ]; then
    echo "Build uboot ok!"
else
    echo -e "\e[0;31;1mBuild uboot failed!\e[0m"
    exit 1
fi


# build kernel
echo    "******************************"
echo    "*     Make AArch64 kernel     *"
echo    "******************************"
cd kernel && make mrproper --jobs=$BUILD_THREAD && make ARCH=arm64 $KERNEL_DEFCONFIG && make ARCH=arm64 $KERNEL_DTS.img --jobs=$BUILD_THREAD && cd -
if [ $? -eq 0 ]; then
    echo "Build kernel ok!"
else
    echo "Build kernel failed!"
    exit 1
fi

# build wifi driver ko
if [ -f "device/rockchip/common/build_wifi_ko.sh" ]; then
    echo "start build wifi driver ko"
    source device/rockchip/common/build_wifi_ko.sh
fi

# build android
echo "start build android"
export CONFIG_BUILD_FACTORY_TOOLS=true
make installclean --jobs=$ANDROID_THREAD && make --jobs=$ANDROID_THREAD
if [ $? -eq 0 ]; then
    echo "Build android ok!"
else
    echo "Build android failed!"
    exit 1
fi

# mkimage.sh
echo "make and copy android images"
./mkimage.sh ota
if [ $? -eq 0 ]; then
    echo "Make image ok!"
else
    echo "Make image failed!"
    exit 1
fi

# copy images to rockdev
#echo "copy u-boot images"
#cp u-boot/uboot.img $IMAGE_PATH/
#cp u-boot/RK322XHMiniLoaderAll* $IMAGE_PATH/
#cp u-boot/trust.img $IMAGE_PATH/

#echo "copy kernel images"
#cp kernel/resource.img $IMAGE_PATH/
#cp kernel/kernel.img $IMAGE_PATH/

# generate update.img
if [ "$BUILD_UPDATE_IMG" = true ] ; then
	echo "generate update.img"
	unzip -o  $PACK_TOOL_DIR/Linux_rockdev_2015-06-17_for_kp0001.zip -d ${IMAGE_PATH}/../update_gen
	cp -rf ${IMAGE_PATH}/parameter.txt ${IMAGE_PATH}/../update_gen/rockdev/parameter.txt
	cp -rf ${IMAGE_PATH}/parameter.txt ${IMAGE_PATH}/../update_gen/rockdev/parameter
	cp -rf ${IMAGE_PATH}/trust.img ${IMAGE_PATH}/../update_gen/rockdev/trust.img
	cp -rf ${IMAGE_PATH}/uboot.img ${IMAGE_PATH}/../update_gen/rockdev/uboot.img
	cp -rf ${IMAGE_PATH}/* ${IMAGE_PATH}/../update_gen/rockdev/Image/

	#Xandy add for secure boot sign
	secure_signer ${IMAGE_PATH}/kp0001_loader.bin ${IMAGE_PATH}/../update_gen/rockdev/Image/MiniLoaderAll.bin
	secure_signer ${IMAGE_PATH}/trust.img ${IMAGE_PATH}/../update_gen/rockdev/Image/trust.img
	secure_signer ${IMAGE_PATH}/uboot.img ${IMAGE_PATH}/../update_gen/rockdev/Image/uboot.img
	secure_signer ${IMAGE_PATH}/boot.img ${IMAGE_PATH}/../update_gen/rockdev/Image/boot.img
	secure_signer ${IMAGE_PATH}/recovery.img ${IMAGE_PATH}/../update_gen/rockdev/Image/recovery.img
	cp -rf ${IMAGE_PATH}/../update_gen/rockdev/Image/MiniLoaderAll.bin ${IMAGE_PATH}/../update_gen/rockdev/kp0001MiniLoaderAll_V1.05.bin
#	gen_user_image
	gen_factory_image

	rm -rf ${IMAGE_PATH}/../update_gen
fi

# generate factory ota update.zip
if [ "$BUILD_OTA" = true ] ; then
  echo "generate ota package"
  mkdir -p ${IMAGE_PATH}/../OTA_PACKAGE
  export CONFIG_BUILD_FACTORY_TOOLS=true
  make installclean --jobs=$ANDROID_THREAD
  
  #secure sign uboot.img
  secure_signer ${U_BOOT_DIR}/uboot.img
  #secure sign trust.img
  secure_signer ${U_BOOT_DIR}/trust.img
  #secure sign boot.img
  secure_signer ${PRODUCT_OUT}/boot.img
  
  make otapackage -j16
  #cp out/target/product/$TARGET_PRODUCT/${TARGET_PRODUCT}*.zip $IMAGE_PATH/ota_$ZIP_FILE.zip
  #md5sum out/target/product/$TARGET_PRODUCT/${TARGET_PRODUCT}*.zip > ota_md5.bin
  #head -c 32 ota_md5.bin > update_md5.bin
  #secure_signer update_md5.bin update_md5_signed.bin
  #cat out/target/product/$TARGET_PRODUCT/${TARGET_PRODUCT}*.zip sign.txt ota_md5_signed.bin > ${IMAGE_PATH}/../OTA_PACKAGE/ota_sign_$ZIP_FILE.zip
  cp out/target/product/$TARGET_PRODUCT/${TARGET_PRODUCT}*.zip ${IMAGE_PATH}/../OTA_PACKAGE/factory_ota_sign_$ZIP_FILE.zip
fi

# generate user ota update.zip
if [ "$BUILD_OTA" = true ] ; then
  echo "generate ota package"
  mkdir -p ${IMAGE_PATH}/../OTA_PACKAGE
  export CONFIG_BUILD_FACTORY_TOOLS=false
  make installclean --jobs=$ANDROID_THREAD
  
  #Only need secure sign boot.img,uboot.img and trust.img have signed at factory ota build
  secure_signer ${PRODUCT_OUT}/boot.img
  
  make otapackage -j16
  #cp out/target/product/$TARGET_PRODUCT/${TARGET_PRODUCT}*.zip $IMAGE_PATH/ota_$ZIP_FILE.zip
  #md5sum out/target/product/$TARGET_PRODUCT/${TARGET_PRODUCT}*.zip > ota_md5.bin
  #head -c 32 ota_md5.bin > update_md5.bin
  #secure_signer update_md5.bin update_md5_signed.bin
  #cat out/target/product/$TARGET_PRODUCT/${TARGET_PRODUCT}*.zip sign.txt ota_md5_signed.bin > ${IMAGE_PATH}/../OTA_PACKAGE/ota_sign_$ZIP_FILE.zip
  cp out/target/product/$TARGET_PRODUCT/${TARGET_PRODUCT}*.zip ${IMAGE_PATH}/../OTA_PACKAGE/user_ota_sign_$ZIP_FILE.zip
  cp out/target/product/$TARGET_PRODUCT/obj/PACKAGING/target_files_intermediates/${TARGET_PRODUCT}*.zip ${IMAGE_PATH}/../OTA_PACKAGE/ota_org_diff_$ZIP_FILE.zip
fi

mkdir -p $STUB_PATH

#Generate patches

#.repo/repo/repo forall  -c '[ "$REPO_REMOTE" = "rk" -a "$REPO_RREV" != "refs/tags/android-6.0.1_r55" ] && { REMOTE_DIFF=`git log $REPO_REMOTE/$REPO_RREV..HEAD`; LOCAL_DIFF=`git diff`; [ -n "$REMOTE_DIFF" ] && { mkdir -p $STUB_PATCH_PATH/$REPO_PATH/; git format-patch $REPO_REMOTE/$REPO_RREV..HEAD -o $STUB_PATCH_PATH/$REPO_PATH; } || :; [ -n "$LOCAL_DIFF" ] && { mkdir -p $STUB_PATCH_PATH/$REPO_PATH/; git reset HEAD ./; git diff > $STUB_PATCH_PATH/$REPO_PATH/local_diff.patch; } || :; }'

echo "Copy project files"
cp .repo/manifest.xml $IMAGE_PATH/manifest_$ZIP_FILE.xml
cp .repo/manifest.xml $STUB_PATH/manifest_$ZIP_FILE.xml
cp kernel/.config $STUB_PATH/config_$ZIP_FILE
cp kernel/vmlinux $STUB_PATH/vmlinux_$ZIP_FILE
cp kernel/System.map $STUB_PATH/System_$ZIP_FILE.map
mv ${IMAGE_PATH}/../FACTORY_IMAGE/factory_update_sign_$ZIP_FILE.img $STUB_PATH

if [ -d "${IMAGE_PATH}/../OTA_PACKAGE/" ]; then
	mv ${IMAGE_PATH}/../OTA_PACKAGE/*_ota_sign_$ZIP_FILE.zip $STUB_PATH/
fi

zip -r $STUB_PATH/symbols_$ZIP_FILE.zip  out/target/product/$TARGET_PRODUCT/symbols

#Save build command info
echo "UBOOT:  defconfig: $UBOOT_DEFCONFIG" >> $STUB_PATH/build_cmd_info_$ZIP_FILE
echo "KERNEL: defconfig: $KERNEL_DEFCONFIG, dts: $KERNEL_DTS" >> $STUB_PATH/build_cmd_info_$ZIP_FILE
echo "ANDROID:$DEVICE-$BUILD_VARIANT" >> $STUB_PATH/build_cmd_info_$ZIP_FILE

#zip package
#echo USER_NAME=$USER_NAME
if [ "$USER_NAME" = "jenkins" ] ; then
	echo -e "\e[0;31;1mJenkins build,now package the images to workspace!\e[0m"
	#zip -r $JENKINS_WORKSPACE/$ZIP_FILE.zip $STUB_PATH/
	cp -rf $STUB_PATH/* $JENKINS_WORKSPACE/
	rm -rf $STUB_PATH
fi
