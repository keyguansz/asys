#!/bin/bash

function usage()
{
cat << EOF
 USAGE: [-d PROJECT_NAME] [-t BUILD_VARIANT]
 No ARGS means use default build option
 WHERE: -d = set device name
        -v = set build version name for output image folder
EOF
 exit 1
}

function h() {
cat <<EOF

已经导入了下列功能函数，可直接当作命令使用：

- mkuboot:     编译uboot
- mkkernel:    编译kernel
- mkandroid:   编译android
- clruboot:    清除uboot
- clrkernel:   清除kernel
- clrandroid:  清除android

- mkmenuconfig:kernel menuconfig配置

- mm:          编译当前目录的模块
- mmm:         编译指定目录的模块
- mkota:       生成OTA升级包：update.zip
- mkall:       编译uboot、kernel、android userdebug

- cdandroid:   切换至android目录
- cdkernel:    切换至kernel目录
- cduboot:     切换至uboot目录	
- cdscripts:   切换到scripts目录

- project:     查看当前项目信息
- h:           帮助


还有一些不常用其他方法，可能需要进入android目录或android下级目录才能使用，如下:
EOF
    local temp
    temp=$PWD
    cd $PROJECT_TOP
    T=$(pwd)
    local A
    A=""
    for i in `cat $T/build/envsetup.sh | sed -n "/^function /s/function \([a-z_]*\).*/\1/p" | sort`; do
      A="$A $i  "
    done
    echo $A
    echo -e "\e[0;31;1m-- by 2018\e[0m"
    cd $temp
}

# sync code function
# now only sync code on the master branch
function synccode()
{
	echo    "******************************"
	echo    "*         repo sync          *"
	echo    "******************************"
	cd $MANIFEST_REPO_DIR
	git checkout -B master
	git pull origin master
		
	.repo/repo/repo start --all master
	.repo/repo/repo sync
}

# build uboot
function mkuboot()
{
	echo    "******************************"
	echo    "*     Make AArch64 Uboot     *"
	echo    "******************************"
	cd $PROJECT_TOP/u-boot && make $UBOOT_DEFCONFIG && make ARCHV=aarch64 --jobs=$BUILD_THREAD && cd -
}

#clean uboot
function clruboot()
{
	echo    "******************************"
	echo    "*     Clean Uboot     *"
	echo    "******************************"
	cd $PROJECT_TOP/u-boot && make distclean --jobs=$BUILD_THREAD && cd -	
}

#kernel menuconfig
function mkmenuconfig()
{
	echo    "******************************"
	echo    "*Make AArch64 kernel menuconfig*"
	echo    "******************************"
	cd $PROJECT_TOP/kernel && make ARCH=arm64 $KERNEL_DEFCONFIG && make menuconfig && cd -		
}

#make kernel
function mkkernel()
{
	echo    "******************************"
	echo    "*     Make AArch64 kernel     *"
	echo    "******************************"
	cd $PROJECT_TOP/kernel
	# Only configure if there is no .config
	if [ ! -f ./.config ]; then
		echo -e "\e[0;31;1mMissing kernel config file .config\e[0m"
		echo "now cp ${KERNEL_DEFCONFIG} as the default config"	
		make ARCH=arm64 $KERNEL_DEFCONFIG
	fi		
	
	make ARCH=arm64 $KERNEL_DTS.img --jobs=$BUILD_THREAD && cd -
}

#clean kernel
function clrkernel()
{
	echo    "******************************"
	echo    "*        Clean kernel        *"
	echo    "******************************"
	cd $PROJECT_TOP/kernel && make mrproper --jobs=$BUILD_THREAD && cd -	
}

#lunch combo
function lunch_combo()
{
	lunch $PROJECT_NAME-$1
	TARGET_PRODUCT=`get_build_var TARGET_PRODUCT`

	if [ "$TARGET_PRODUCT" != "$PROJECT_NAME" ];then
		echo -e "\e[0;31;1mHave you lunch the combo?\e[0m"
	fi
}

#make android
function mkandroid()
{
	case "$1" in
		"user")
			export CONFIG_ENABLE_USER_ADB_ROOT=true
			lunch_combo user
			;;
		"eng")
			lunch_combo eng
			;;
		"userdebug")
			lunch_combo userdebug
			;;
		?)
			lunch_combo userdebug
			;;
	esac

	cd $PROJECT_TOP && make --jobs=$ANDROID_THREAD 2>&1 | tee android_build.log && ./mkimage.sh && cd -
}

#clean android
function clrandroid()
{
	echo    "******************************"
	echo    "*        Clean android       *"
	echo    "******************************"
	cd $PROJECT_TOP && make installclean --jobs=$BUILD_THREAD && cd -	
}

#build ota package
function mkota()
{
	echo "generate ota package"
	cd $PROJECT_TOP && make otapackage --jobs=$BUILD_THREAD && cd -
}

function mkall()
{
	cd $PROJECT_TOP
	clruboot && clrkernel && clrandroid && \
	mkuboot && mkkernel && mkandroid && ./mkimage.sh && cd -
}

if [ $# -eq 0 ];then
	usage
fi

function cdscripts()
{
	cd $PROJECT_TOP/scripts
}

function cduboot()
{
	cd $PROJECT_TOP/u-boot
}

function cdkernel()
{
	cd $PROJECT_TOP/kernel
}

function cdandroid()
{
	cd $PROJECT_TOP
}

function updatemanifest()
{
	cd $PROJECT_TOP
	.repo/repo/repo forall -c "git pull KKK master"
	if [ $? = 0 ]; then
		.repo/repo/repo manifest -r --suppress-upstream-revision -o manifest.xml
		cp manifest.xml .repo/
	else
		echo -e "\e[0;31;1m更新manifest.xml失败\e[0m"
	fi
	cd -
}

function project()
{ 
    echo 当前项目为： $PROJECT_NAME
    printconfig
}

# check pass argument
while getopts "d:t:v:" arg
do
  case $arg in
	d)
	  PROJECT_NAME=$OPTARG
	  echo -e "\e[0;31;1mSetup $PROJECT_NAME build environment!\e[0m"
	  ;;
    v)
      KKK_BUILD_VERSION=$OPTARG
	  ;;	  
    ?)
      usage ;;
  esac
done

SDK_ROOT=../
#export build version to build environment
export ANDROID_BUILD_ID=$KKK_BUILD_VERSION

source $SDK_ROOT/build/envsetup.sh >/dev/null && setpaths

lunch $PROJECT_NAME-userdebug
export TARGET_PRODUCT=`get_build_var TARGET_PRODUCT`

if [ "$TARGET_PRODUCT" != "$PROJECT_NAME" ];then
	echo -e "\e[0;31;1mHave you lunch the combo?\e[0m"
	exit 0
fi

#set jdk version
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib:$JAVA_HOME/lib/tools.jar
# source environment and chose target product
DEVICE=`get_build_var TARGET_PRODUCT`
#BUILD_VARIANT=`get_build_var TARGET_BUILD_VARIANT`
export UBOOT_DEFCONFIG=${PROJECT_NAME}_defconfig
export KERNEL_DEFCONFIG=${PROJECT_NAME}_defconfig
export KERNEL_DTS=${PROJECT_NAME}
export MANIFEST_REPO_DIR=$SDK_ROOT/.repo/manifests
export IMAGE_PATH=$SDK_ROOT/rockdev/Image-$TARGET_PRODUCT
export PROJECT_TOP=`gettop`
#export build version to build environment
export ANDROID_BUILD_ID=$KKK_BUILD_VERSION

#BUILD_THREAD
export BUILD_THREAD=`sed -n "N;/processor/p" /proc/cpuinfo|wc -l`
let ANDROID_THREAD=$BUILD_THREAD/4
export ANDROID_THREAD

echo -e "\e[0;31;1m导入环境变量设置完成..输入h回车查看帮助!\e[0m"
