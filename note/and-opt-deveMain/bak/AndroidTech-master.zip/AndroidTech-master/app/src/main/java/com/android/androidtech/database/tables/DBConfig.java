package com.android.androidtech.database.tables;

/**
 * Created by yuchengluo on 2015/6/29.
 */
public interface DBConfig {
    public static final String DATABASE_FILE = "QmfDb"; // DB文件名
    public static final int DB_VER = 1; //
}
