package com.android.androidtech.monitor;

/**
 * Created by yuchengluo on 2016/3/31.
 */
public class MonitorConfig {
    static boolean ENABLE_UI_PERF_MONITOR = true;
}
