package com.android.androidtech.monitor.time;

/**
 * Created by yuchengluo on 2016/3/25.
 */
public class TimeMonitorConfig {
    public static final int TIME_MONITOR_ID_APPLICATION_START = 1;
    public static final int TIME_MONITOR_ID_SQLITE= 2;
}
