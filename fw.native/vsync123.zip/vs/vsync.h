#ifndef VSYNC_H_
#define VSYNC_H_

#include <utils/threads.h>
#include <utils/Vector.h>
#include <semaphore.h>
//#include <utils/define.h>

#include <gui/DisplayEventReceiver.h>
#include <media/stagefright/ACodec.h>

namespace android
{
#define USE_GRAPHIC_BUFFER
class VsyncReciver : public RefBase
{
public:
    VsyncReciver(void* player);
    ~VsyncReciver();
    static void* startthread(void* parm);
    static int receiver(int fd, int events, void* data);
/*
#ifdef USE_IPTV
    RkFFTsPlayerBase * mplayer;
#else
    FFMPlayerBase	 * mplayer;
#endif
*/
    DisplayEventReceiver myDisplayEvent;

    int 					FrameAlign(ACodec* player, int64_t count, float rate);
    bool 					abandon_frame(int abandon);
    bool 					abandon_frame_base(int abandon);
	bool					VsyncMatchFrameRate(int64_t count, int rate);
    void                    computeFrameAbandonNum(float hdmirate);
    int 					match_frame_to_hdmi(int hdmi_freq, float video_rate);
    int						GetAbandonFrameNum();
    void 					stopVsyncThread();
    bool 					IsFrameRateMatchVsync(double frameRate);
    void                    startThread();

    int                     	mVsyncThreadStatus;
    bool						vsync_thread;
	bool						mHdmiConnected;
	bool						mHdmiPassFrame;
    pthread_t 					thread_id;
    int64_t 					phase;
	int64_t						mDelayCount;
    int							mFrameRate;
    int							vsync_rate;
    bool 						startalign;
    int							hdmi_cnt;
	int						mPrevFrameRate;
	int						mTick;


    int64_t vsync_count;
    int	mFrameAbandon;
    int abd_time_for_50;
    int abd_time_for_60;
    int abd_time;
    int abd_time_for_120;

private:
	ACodec* mplayer;
};

}

#endif /* VSYNC_H_  */
