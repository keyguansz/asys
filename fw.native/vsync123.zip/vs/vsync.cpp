#define ATRACE_TAG ATRACE_TAG_GRAPHICS

#define LOG_TAG "VsyncReciver"
#include <math.h>
#include <gui/DisplayEventReceiver.h>
#include <utils/Looper.h>
#include <cutils/properties.h>
#include "vsync.h"
#include <sys/resource.h>
#include "utils/CallStack.h"
#include "android/looper.h"
#include <media/stagefright/ACodec.h>

//#Include "QosProbe/TraceThread.h"
using namespace android;

bool VsyncReciver::abandon_frame(int abandon)
{
    if ((abandon < 50) && (abandon == 5)) {
        abd_time_for_50++;
        if (abd_time_for_50 == abandon) {
            abd_time_for_50 = 0;
            return false;
        } else if (abd_time_for_50%2) {
            return false;
        } else {
            return true;
        }
    } else {
        abd_time_for_50++;
        if (abd_time_for_50 == abandon) {
            abd_time_for_50 = 0;
            return true;
        } else if (abd_time_for_50%2) {
            return true;
        } else {
            return false;
        }
    }
    return false;
}

bool VsyncReciver::abandon_frame_base(int abandon)
{
    ALOGV("for 5.0 display framework abandon_frame, abandon = %d", abandon);
    if ((abandon < 50) && (abandon)) {
        if (abd_time++ == abandon) {
            abd_time = 0;
            return true;
        } else {
            return false;
        }
    } else if (abandon == 60) {
        ALOGV("for 24 hdmi freq to 60 frame rate");
        abd_time_for_60++;
        if (abd_time_for_60%2 == 0) {
            return false;
        } else if (abd_time_for_60 == 5) {
            abd_time_for_60 = 0;
            return true;
        } else {
            return true;
        }
    } else if (abandon == 120) {
        ALOGV("for 25 hdmi freq to 60 frame rate");
        abd_time_for_120 ++;
        if ((abd_time_for_120%2 == 0) && (abd_time_for_120 != 12)) {
            return false;
        } else if (abd_time_for_120 == 12) {
            abd_time_for_120 = 0;
            return true;
        } else {
            return true;
        }
    } else {
        return false;
    }
}

int VsyncReciver::match_frame_to_hdmi(int hdmi_freq, float video_rate)
{
    if (video_rate > hdmi_freq) {
        ALOGV("for match frame to hdmi rate hdmi_freq = %d, video_rate = %.2f",hdmi_freq,video_rate);
        switch (hdmi_freq) {
        case 24 :
            if ((video_rate > 24.5) && (video_rate < 25.5)) {
                return 24/1;
            } else if ((video_rate > 29) && (video_rate < 31)) {
                return 4/1;
            } else if ((video_rate >= 59) && (video_rate < 61)) {
                return 60;
                //return 0;
            } else {
                return 0;
            }
            break;
        case 25 :
            if ((video_rate > 29) && (video_rate <31)) {
                return 5/1;
            } else if ((video_rate >= 59) && (video_rate < 61)) {
                return 120;
                //return 0;
            } else {
                return 0;
            }
            break;
        case 30 :
            if ((video_rate >= 59) && (video_rate < 61)) {
                return 1/1;
            } else {
                return 0;
            }
            break ;
        case 50 :
            if ((video_rate >= 59) && (video_rate < 61)) {
                return 5/1;
            } else {
                return 0;
            }
            break;
        default :
            return 0;
        }
    } else {
        return 0;
    }
}

void VsyncReciver::computeFrameAbandonNum(float hdmirate)
{
    if (hdmirate < 61.5 && hdmirate > 58) {
        vsync_rate = 60;
        hdmi_cnt = 0;
    } else if (hdmirate <= 51 && hdmirate >= 49) {
        vsync_rate = 50;
        hdmi_cnt = 0;
    } else if (hdmirate <= 31 && hdmirate >= 29) {
        vsync_rate = 30;
        hdmi_cnt = 0;
    } else if (hdmirate < 24.5 && hdmirate >= 23.5) {
        vsync_rate = 24;
        hdmi_cnt = 0;
    } else if (hdmirate <= 26 && hdmirate > 24.5) {
        vsync_rate = 25;
        hdmi_cnt = 0;
    } else {
        hdmi_cnt++;
        if (hdmi_cnt >= 4) {
            vsync_rate = -1;
            //          ALOGD("vsync_rate = -1 hdmirate = %f**********", hdmirate);
        }
    }
    if (vsync_rate > 0)
        mFrameAbandon = match_frame_to_hdmi(vsync_rate,(float)mFrameRate);
}

bool VsyncReciver::VsyncMatchFrameRate(int64_t count, int rate)
{
	bool render;

    char value[PROPERTY_VALUE_MAX];
    property_get("dji.camera.fps", value, "0");
	mFrameRate = atoi(value);

	if(mPrevFrameRate != mFrameRate){
		memset(value, 0, sizeof(value));
		if(mFrameRate > 30){
			mTick = 1;
			sprintf(value, "%d", mFrameRate);
		}else{
			mTick = 2;
			sprintf(value, "%d", mFrameRate * 2);
		}
		property_set("prop.dji.fps", value);
		mPrevFrameRate = mFrameRate;
	}

	if(mTick == 1 || mHdmiPassFrame)
		return true;
	else
		return count % mTick;
}

int VsyncReciver::FrameAlign(ACodec* player, int64_t count, float rate)
{
    bool needRender;

	needRender = VsyncMatchFrameRate(count, round(rate));

    if(needRender) {
		if(player){
        	player->callback();
		}
        if (player->mVsyncDebugOn)
            ALOGD("FrameAlign callback count %lld rate %f ************", count, rate);
    }
    return 0;
}

int VsyncReciver::GetAbandonFrameNum()
{
    return mFrameAbandon;
}

bool VsyncReciver::IsFrameRateMatchVsync(double frameRate)
{
    if (frameRate > 29 && frameRate < 31) {
        return true;
    } else if (frameRate <= 61 && frameRate >= 59) {
        return true;
    } else if (frameRate < 24.5 && frameRate > 23.5) {
        return true;
    } else if (frameRate < 25.5 && frameRate > 24.5) {
        return true;
    } else if (frameRate < 51 && frameRate > 49) {
        return true;
    } else {
        return false;
    }
    return false;

}

int VsyncReciver::receiver(int fd, int events, void* data)
{
    //  DisplayEventReceiver* q = (DisplayEventReceiver*)data;
    VsyncReciver* mvsync = (VsyncReciver*)data;
    if (mvsync == NULL) {
        return NULL;
    }

	if(mvsync->mplayer == NULL){
		return NULL;
	}
	
    DisplayEventReceiver* q = &(mvsync->myDisplayEvent);
    ssize_t n;
    DisplayEventReceiver::Event buffer[1];

    //ALOGD("receiver**************");
    while ((n = q->getEvents(buffer, 1)) > 0) {
        for (int i=0 ; i<n ; i++) {
			
			if(!mvsync->vsync_thread){
				return 1;
			}
			
            if (buffer[i].header.type == DisplayEventReceiver::DISPLAY_EVENT_VSYNC) {
                //ALOGE("==============event vsync: count=%d\t", buffer[i].vsync.count);
            }

			if(buffer[i].header.type == DisplayEventReceiver::DISPLAY_EVENT_HOTPLUG){
				mvsync->mHdmiConnected = buffer[i].hotplug.connected;
				mvsync->mHdmiPassFrame = mvsync->mHdmiConnected;
				ALOGD("******hdmi connected(%d)******",mvsync->mHdmiConnected);
			}
			
            if (mvsync->mplayer->mLastVsyncTime) {
                float t = float(buffer[i].header.timestamp - mvsync->mplayer->mLastVsyncTime) / s2ns(1);

                if (0) {
                    ALOGE("[this=%p]%f ms (%f Hz), buffer[%d].count = %d\n", mvsync, t*1000, 1.0/t,i,buffer[i].vsync.count);
                }
                mvsync->mplayer->mCurVsyncTime = buffer[i].header.timestamp;
				mvsync->mplayer->phase = ALooper::GetNowUs() - buffer[i].header.timestamp / 1000;
				mvsync->FrameAlign(mvsync->mplayer, buffer[i].vsync.count, 1.0/t);
				// ALOGD("timeout [this=%p]%f ms (%f Hz), buffer[%d].count = %d phase %ld\n", mvsync, t*1000, 1.0/t,i,buffer[i].vsync.count,mvsync->mplayer->phase);
				if(mvsync->mHdmiConnected){
					if(mvsync->mDelayCount == 0){
						mvsync->mDelayCount = mvsync->mplayer->mCurVsyncTime;
					}

					if(mvsync->mplayer->mCurVsyncTime - mvsync->mDelayCount > 5)
						mvsync->mHdmiPassFrame = false;
				}else{
					mvsync->mDelayCount = 0;
				}
			}
            //oldTimeStamp = buffer[i].header.timestamp;
            mvsync->mplayer->mLastVsyncTime = buffer[i].header.timestamp;
        }
    }
    if (n<0) {
        ALOGE("error reading events (%s)\n", strerror(-n));
    }

    return 1;
}

void* VsyncReciver::startthread(void* parm)
{
    VsyncReciver* mvsync = (VsyncReciver*)parm;
    if (mvsync == NULL) {
        return NULL;
    }

    //prctl(PR_SET_NAME, (unsigned long)"VsyncReciver", 0, 0, 0);
    //TraceThread::getInstance()->writeTrace(mvsync->thread_id, LOG_TAG, "VsyncReciver::startthread");


    if (!mvsync->myDisplayEvent.getFd()) {
        ALOGD("VsyncReciver::startthread getFd error");
        return NULL;
    }
    sp<Looper> loop = new Looper(false);
    loop->addFd(mvsync->myDisplayEvent.getFd(), 0,
                ALOOPER_EVENT_INPUT, VsyncReciver::receiver,parm);
    
    ALOGD("VsyncReciver startthread ****************");
    mvsync->myDisplayEvent.setVsyncRate(1);
    do {
        //printf("about to poll...\n");
        int32_t ret = loop->pollOnce(100);
        switch (ret) {
        case  ALOOPER_POLL_WAKE:
            //("ALOOPER_POLL_WAKE\n");
            break;
        case  ALOOPER_POLL_CALLBACK:
            //("ALOOPER_POLL_CALLBACK\n");
            break;
        case  ALOOPER_POLL_TIMEOUT:
            ALOGE("ALOOPER_POLL_TIMEOUT\n");
            break;
        case  ALOOPER_POLL_ERROR:
            ALOGE("ALOOPER_POLL_TIMEOUT\n");
            break;
        default:
            ALOGE("ugh? poll returned %d\n", ret);
            break;
        }

        //ALOGD("startthread(0*************");
    } while (mvsync->vsync_thread);

    if (loop.get()) {
        loop->removeFd(mvsync->myDisplayEvent.getFd());
        loop.clear();
        loop = NULL;
    }

	ALOGD("vsyncThrad stop");
    return 0;
}

void VsyncReciver::stopVsyncThread()
{
    if (mVsyncThreadStatus >= 0) {
        vsync_thread = false;

        //TraceThread::getInstance()->writeTraceWithFormat(thread_id, LOG_TAG,
        //        "pthread_join begin-->player = %p", mvsync->mplayer);
        if (pthread_join(thread_id, NULL) != 0) {
            ALOGE("Couldn't cancel vsync thread ");
        }

        //TraceThread::getInstance()->writeTraceWithFormat(thread_id, LOG_TAG,
        //        "pthread_join   end-->player = %p", mvsync->mplayer);

        thread_id = 0;
        mVsyncThreadStatus = -1;
    }
    ALOGD("stop_l:vsyncThread down");
}

VsyncReciver::VsyncReciver(void * player)
{
    thread_id = 0;
    vsync_thread = true;
    mFrameAbandon = 0;
    vsync_count = 0;
    abd_time_for_50 = 0;
    abd_time_for_60 = 0;
    abd_time = 0;
    abd_time_for_120 = 0;
    vsync_count = 0;
    startalign = false;
    phase = 0;
    vsync_rate = 0;
    hdmi_cnt = 0;
	mDelayCount = 0;
	mHdmiPassFrame = false;
	mHdmiConnected = false;
/*
#ifdef USE_IPTV
    mvsync->mplayer = (RkFFTsPlayerBase*)player;
#else
    mvsync->mplayer = (FFMPlayerBase*)player;
#endif
*/
    mplayer = (ACodec*)player;
#ifdef USE_GRAPHIC_BUFFER
#ifndef HIMEDIA
    mVsyncThreadStatus = pthread_create(&thread_id, NULL, startthread, this);
    setpriority(PRIO_PROCESS, thread_id, ANDROID_PRIORITY_DISPLAY);
#endif

#endif

}

VsyncReciver::~VsyncReciver()
{
#ifdef USE_GRAPHIC_BUFFER
    stopVsyncThread();
#endif
}

void VsyncReciver::startThread()
{
#ifdef USE_GRAPHIC_BUFFER
    //There are two VsyncReciver thread maybe; Release old one
    mVsyncThreadStatus = pthread_create(&thread_id, NULL, startthread, this);
    setpriority(PRIO_PROCESS, thread_id, ANDROID_PRIORITY_DISPLAY);

   //TraceThread::getInstance()->writeTraceWithFormat(0, LOG_TAG,
   //         "pthread_create with(player = %p) OK; thread_id=%u", mvsync->mplayer, thread_id);
#endif
}

